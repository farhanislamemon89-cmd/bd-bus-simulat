package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.game.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val gameViewModel: GameViewModel = viewModel()
                val currentScreen by gameViewModel.currentScreen.collectAsState()

                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    // Full-bleed Edge-to-edge screens with inner padding applied internally in subcomponents
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(DeepSlateBg)
                    ) {
                        when (currentScreen) {
                            is GameScreen.Splash -> {
                                SplashScreen {
                                    gameViewModel.navigateTo(GameScreen.Menu)
                                }
                            }
                            is GameScreen.Menu -> MainMenuScreen(gameViewModel)
                            is GameScreen.RouteSelect -> RouteSelectScreen(gameViewModel)
                            is GameScreen.Garage -> GarageScreen(gameViewModel)
                            is GameScreen.Stats -> StatsScreen(gameViewModel)
                            is GameScreen.Settings -> SettingsScreen(gameViewModel)
                            is GameScreen.Driving -> GamePlayScreen(gameViewModel)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    var startAnimation by remember { mutableStateOf(false) }
    
    val alphaAnim = animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0f,
        animationSpec = tween(1000, easing = LinearOutSlowInEasing),
        label = "splash_fade"
    )

    val scaleAnim = animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0.85f,
        animationSpec = tween(1200, easing = FastOutSlowInEasing),
        label = "splash_scale"
    )

    LaunchedEffect(key1 = true) {
        startAnimation = true
        delay(1800) // 1.8 seconds loading transit
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.graphicsLayer(
                alpha = alphaAnim.value,
                scaleX = scaleAnim.value,
                scaleY = scaleAnim.value
            )
        ) {
            // Stylized Bangladesh Flag Core icon
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF006A4E)),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFF42A41))
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            Text(
                text = "BANGLADESH",
                fontSize = 14.sp,
                color = Color(0xFF00E676),
                fontWeight = FontWeight.Bold,
                letterSpacing = 4.sp
            )
            
            Text(
                text = "BUS SIMULATOR",
                fontSize = 26.sp,
                color = Color.White,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(48.dp))

            CircularProgressIndicator(
                color = Color(0xFFFF9800),
                strokeWidth = 3.dp,
                modifier = Modifier.size(36.dp)
            )
        }
    }
}
