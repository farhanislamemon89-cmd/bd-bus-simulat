package com.example.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "player_stats")
data class PlayerStats(
    @PrimaryKey val id: Int = 1,
    val money: Int = 5000, // Balance in Bangladeshi Taka (৳)
    val unlockedBusesJson: String = "Hino 1J", // Comma-separated or simple JSON
    val currentBusId: String = "Hino 1J",
    val currentSkinId: String = "Hanif Travels",
    val totalFaresEarned: Int = 0,
    val totalPassengersTransported: Int = 0,
    val totalViolations: Int = 0,
    val totalDistanceDrivenKm: Double = 0.0,
    val selectedLanguage: String = "en", // "en" for English, "bn" for Bangla
    val controlType: String = "Buttons", // "Buttons", "Steering Wheel", "Tilt"
    val soundVolume: Float = 0.8f,
    val graphicsQuality: String = "Ultra" // "Low", "Medium", "Ultra"
)
