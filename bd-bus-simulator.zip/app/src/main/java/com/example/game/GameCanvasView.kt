package com.example.game

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import java.util.Random
import kotlin.math.sin

// Representation of an AI vehicle on the road
data class AIVehicle(
    val type: String, // "Rickshaw", "CNG", "Truck", "Car"
    var x: Float,     // Horizontal offset (0.1 to 0.9)
    var y: Float,     // Vertical screen coordinate
    val speedFactor: Float,
    val color: Color,
    val stripeColor: Color = Color.White
)

@Composable
fun GameCanvasView(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val activeRoute = viewModel.activeRoute.collectAsState().value ?: return
    val speed = viewModel.activeSpeed.collectAsState().value
    val steeringAngle = viewModel.steeringAngle.collectAsState().value
    val headlights = viewModel.headlightsOn.collectAsState().value
    val wipers = viewModel.wipersOn.collectAsState().value
    val drivePhase = viewModel.drivePhase.collectAsState().value
    val progress = viewModel.driveProgress.collectAsState().value
    val stats = viewModel.playerStats.collectAsState().value

    // Load active bus model specs
    val activeBus = BusRegistry.getBus(stats.currentBusId)
    val activeSkin = activeBus.skins.firstOrNull { it.id == stats.currentSkinId } ?: activeBus.skins[0]

    // Visual animation states
    var scrollOffset by remember { mutableStateOf(0f) }
    var tickCounter by remember { mutableStateOf(0) }
    var wiperAngle by remember { mutableStateOf(-60f) }
    var wiperDirection by remember { mutableStateOf(1) }

    // Steer angle interpolation for bus horizontal position
    var busXOffset by remember { mutableStateOf(0.5f) } // centered on highway

    // Spawning traffic
    val trafficList = remember { mutableStateListOf<AIVehicle>() }
    val random = remember { Random() }

    // Render loop and updates at 60Hz
    LaunchedEffect(speed, drivePhase) {
        var lastTime = System.currentTimeMillis()
        while (true) {
            val now = System.currentTimeMillis()
            val dt = (now - lastTime) / 1000f
            lastTime = now

            // Update scroll offset for highway stripes
            if (drivePhase != "BOARDING" && drivePhase != "FERRY_TRANSIT" && drivePhase != "COMPLETED") {
                scrollOffset = (scrollOffset + speed * dt * 8f) % 200f
            }

            // Adjust bus position based on steering wheel angle
            if (Math.abs(speed) > 1f) {
                val steerFactor = (steeringAngle / 360f) * dt * 0.4f * (speed / 100f).coerceIn(-1f, 1f)
                busXOffset = (busXOffset + steerFactor).coerceIn(0.12f, 0.88f)

                // Detect if player drove off-road (into shoulders)
                if (busXOffset < 0.2f || busXOffset > 0.8f) {
                    if (random.nextInt(45) == 0) {
                        viewModel.triggerCollisionCrash()
                    }
                }
            }

            // Animate Wipers
            if (wipers) {
                wiperAngle += wiperDirection * 4f
                if (wiperAngle > 60f) {
                    wiperAngle = 60f
                    wiperDirection = -1
                } else if (wiperAngle < -60f) {
                    wiperAngle = -60f
                    wiperDirection = 1
                }
            } else {
                if (wiperAngle > -60f) wiperAngle -= 2f
            }

            // Spawning & Scrolling AI Traffic
            if (drivePhase == "DRIVING" || drivePhase == "DESTINATION_APPROACH" || drivePhase == "TOLL_PLAZA") {
                // Update traffic positions
                val iterator = trafficList.iterator()
                while (iterator.hasNext()) {
                    val vehicle = iterator.next()
                    // AI scrolls downwards relative to the player bus speed
                    val relativeSpeed = (speed - vehicle.speedFactor) * dt * 10f
                    vehicle.y += relativeSpeed

                    // Check collisions between Player and AI Traffic
                    if (Math.abs(vehicle.y - 650f) < 45f && Math.abs((vehicle.x - busXOffset)) < 0.11f) {
                        viewModel.triggerCollisionCrash()
                        vehicle.y = -200f // bump off screen
                    }

                    // Recycle out-of-screen traffic
                    if (vehicle.y > 1100f || vehicle.y < -300f) {
                        iterator.remove()
                    }
                }

                // Spawn new traffic
                if (trafficList.size < 5 && random.nextInt(120) == 0) {
                    val types = listOf("Rickshaw", "CNG", "Truck", "Car")
                    val type = types[random.nextInt(types.size)]
                    val lane = if (random.nextBoolean()) 0.35f else 0.65f // lane positions
                    val vehicleColor = when (type) {
                        "Rickshaw" -> Color(0xFFD32F2F)
                        "CNG" -> Color(0xFF2E7D32)
                        "Truck" -> Color(0xFF1565C0)
                        else -> Color(0xFF37474F)
                    }
                    trafficList.add(
                        AIVehicle(
                            type = type,
                            x = lane + (random.nextFloat() * 0.08f - 0.04f),
                            y = -150f,
                            speedFactor = when (type) {
                                "Rickshaw" -> 15f
                                "CNG" -> 35f
                                "Truck" -> 55f
                                else -> 70f
                            },
                            color = vehicleColor
                        )
                    )
                }
            } else {
                trafficList.clear()
            }

            tickCounter++
            kotlinx.coroutines.delay(16) // ~60 FPS
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // 1. Draw rural landscape background (fields, shoulders)
            drawLandscape(width, height, activeRoute, progress, drivePhase)

            // 2. Draw asphalt highway
            drawHighway(width, height, scrollOffset)

            // 3. Draw roadside decorations (Tea Stalls, Mosques, Trees, Toll booth, railway, etc.)
            drawRoadsideElements(width, height, scrollOffset, progress, drivePhase, activeRoute, tickCounter)

            // 4. Draw AI Traffic Vehicles
            drawAITraffic(width, height, trafficList)

            // 5. Draw Player's Bus
            drawPlayerBus(width, height, busXOffset, activeSkin, headlights, tickCounter, speed)

            // 6. Draw Weather Overlays (Rain/Fog/Night Headlights)
            drawWeatherEffects(width, height, activeRoute.defaultWeather, headlights, wipers, wiperAngle, tickCounter, busXOffset)
        }
    }
}

// ----------------------------------------------------
// CANVAS DRAWING EXTENSION FUNCTIONS
// ----------------------------------------------------

private fun DrawScope.drawLandscape(
    w: Float, h: Float,
    route: RouteSpec,
    progress: Float,
    phase: String
) {
    // Determine grass color depending on weather/scenery
    val grassColor = when (route.defaultWeather) {
        "Rain" -> Color(0xFF1E5E3A) // lush wet green
        "Fog" -> Color(0xFF3E5C4E)  // cold desaturated green
        "Night" -> Color(0xFF0F2B1B) // dark midnight green
        else -> Color(0xFF2E7D32)    // standard sunny green
    }

    // Ground grass plain
    drawRect(color = grassColor, size = Size(w, h))

    // Draw rivers/water bodies on Barishal or Sylhet routes
    if (route.hasFerry && progress in 0.65f..0.75f) {
        val riverColor = Color(0xFF1976D2)
        // River belt slicing across the highway
        drawRect(
            color = riverColor,
            topLeft = Offset(0f, h * 0.15f),
            size = Size(w, h * 0.5f)
        )
        // Waves
        for (i in 0..5) {
            val waveY = h * 0.18f + i * (h * 0.08f)
            val waveShift = (sin((System.currentTimeMillis() / 200f) + i) * 15f)
            drawLine(
                color = Color(0xFF64B5F6),
                start = Offset(0f, waveY),
                end = Offset(w, waveY + waveShift),
                strokeWidth = 3f
            )
        }
    }
}

private fun DrawScope.drawHighway(w: Float, h: Float, scroll: Float) {
    // Road boundaries
    val leftShoulder = w * 0.15f
    val rightShoulder = w * 0.85f
    val roadWidth = rightShoulder - leftShoulder

    // Asphalt body
    drawRect(
        color = Color(0xFF303030),
        topLeft = Offset(leftShoulder, 0f),
        size = Size(roadWidth, h)
    )

    // Road side safety solid lines
    drawLine(
        color = Color(0xFFE0E0E0),
        start = Offset(leftShoulder, 0f),
        end = Offset(leftShoulder, h),
        strokeWidth = 6f
    )
    drawLine(
        color = Color(0xFFE0E0E0),
        start = Offset(rightShoulder, 0f),
        end = Offset(rightShoulder, h),
        strokeWidth = 6f
    )

    // Highway median yellow dashed dividing lines
    val dashLength = 40f
    val dashGap = 30f
    val totalDashPeriod = dashLength + dashGap
    val startY = -totalDashPeriod + (scroll % totalDashPeriod)

    var currentY = startY
    while (currentY < h) {
        drawLine(
            color = Color(0xFFFFD54F),
            start = Offset(w * 0.5f, currentY),
            end = Offset(w * 0.5f, (currentY + dashLength).coerceAtMost(h)),
            strokeWidth = 5f
        )
        currentY += totalDashPeriod
    }
}

private fun DrawScope.drawRoadsideElements(
    w: Float, h: Float,
    scroll: Float,
    progress: Float,
    phase: String,
    route: RouteSpec,
    ticks: Int
) {
    // Draw trees along the road shoulders periodically
    val treePeriod = 300f
    val startTreeY = -treePeriod + (scroll * 1.5f % treePeriod)
    var currentTreeY = startTreeY
    while (currentTreeY < h) {
        // Left trees
        drawCircle(
            color = Color(0xFF1B5E20),
            radius = 35f,
            center = Offset(w * 0.08f, currentTreeY)
        )
        drawCircle(
            color = Color(0xFF2E7D32),
            radius = 25f,
            center = Offset(w * 0.08f + 10f, currentTreeY - 10f)
        )

        // Right coconut trees
        drawCircle(
            color = Color(0xFF0D5C3A),
            radius = 40f,
            center = Offset(w * 0.92f, currentTreeY + 120f)
        )
        currentTreeY += treePeriod
    }

    // 1. Draw Local Tea Stall ("Tong Ghor") at progress 15% on Left
    if (progress in 0.12f..0.22f) {
        val yPos = h * 0.3f
        // Wood cabin
        drawRect(
            color = Color(0xFF8D6E63),
            topLeft = Offset(w * 0.02f, yPos),
            size = Size(w * 0.1f, 80f)
        )
        // Red tin roof
        drawRect(
            color = Color(0xFFD32F2F),
            topLeft = Offset(w * 0.01f, yPos - 15f),
            size = Size(w * 0.12f, 20f)
        )
        // Yellow banner "Ttong Ghor"
        drawRect(
            color = Color(0xFFFFEB3B),
            topLeft = Offset(w * 0.025f, yPos + 10f),
            size = Size(w * 0.09f, 25f)
        )
    }

    // 2. Draw local Mosque dome on Right shoulder at progress 40%
    if (progress in 0.36f..0.46f) {
        val yPos = h * 0.45f
        // Mosque white building
        drawRect(
            color = Color(0xFFEEEEEE),
            topLeft = Offset(w * 0.86f, yPos),
            size = Size(w * 0.11f, 100f)
        )
        // Golden Islamic Dome
        drawArc(
            color = Color(0xFFFBC02D),
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = true,
            topLeft = Offset(w * 0.875f, yPos - 35f),
            size = Size(w * 0.08f, 70f)
        )
    }

    // 3. Toll Plaza concrete barrier block (when phase is TOLL_PLAZA)
    if (phase == "TOLL_PLAZA" || (route.hasToll && progress in 0.23f..0.29f)) {
        val tollY = h * 0.35f
        // Left barrier booth
        drawRect(
            color = Color(0xFF78909C),
            topLeft = Offset(w * 0.15f, tollY),
            size = Size(w * 0.12f, 60f)
        )
        // Right barrier booth
        drawRect(
            color = Color(0xFF78909C),
            topLeft = Offset(w * 0.73f, tollY),
            size = Size(w * 0.12f, 60f)
        )

        // Barrier gates (open if progress > 0.26f, closed otherwise)
        val isClosed = phase == "TOLL_PLAZA"
        val gateColor = if (isClosed) Color(0xFFD32F2F) else Color(0xFF388E3C)
        val gateY = tollY + 28f

        if (isClosed) {
            // Draw closed gates extending across lanes
            drawLine(
                color = gateColor,
                start = Offset(w * 0.27f, gateY),
                end = Offset(w * 0.73f, gateY),
                strokeWidth = 10f
            )
            // Black/yellow hazards lines
            for (i in 0..10) {
                drawLine(
                    color = Color(0xFFFFEB3B),
                    start = Offset(w * 0.3f + i * 30f, gateY - 5f),
                    end = Offset(w * 0.32f + i * 30f, gateY + 5f),
                    strokeWidth = 4f
                )
            }
        } else {
            // Drawn standing up (open)
            drawLine(
                color = Color(0xFF388E3C),
                start = Offset(w * 0.27f, gateY),
                end = Offset(w * 0.27f, gateY - 120f),
                strokeWidth = 10f
            )
            drawLine(
                color = Color(0xFF388E3C),
                start = Offset(w * 0.73f, gateY),
                end = Offset(w * 0.73f, gateY - 120f),
                strokeWidth = 10f
            )
        }
    }

    // 4. Railway Crossing (when phase is RAILWAY_GATE)
    if (phase == "RAILWAY_GATE" || (route.hasRailwayCrossing && progress in 0.47f..0.54f)) {
        val railY = h * 0.35f
        // Metal train tracks crossing road horizontally
        drawRect(color = Color(0xFF212121), topLeft = Offset(0f, railY), size = Size(w, 25f))
        drawLine(color = Color(0xFF757575), start = Offset(0f, railY + 5f), end = Offset(w, railY + 5f), strokeWidth = 3f)
        drawLine(color = Color(0xFF757575), start = Offset(0f, railY + 20f), end = Offset(w, railY + 20f), strokeWidth = 3f)

        // Draw railway ties (wood blocks)
        for (i in 0..25) {
            drawRect(color = Color(0xFF4E342E), topLeft = Offset(i * (w / 25f), railY), size = Size(10f, 25f))
        }

        val crossingClosed = phase == "RAILWAY_GATE"

        // Train visual passing horizontally if crossing closed
        if (crossingClosed) {
            val trainX = (ticks * 12f) % (w + 1000f) - 600f
            // Long red/green passenger train (Classic Bangladesh Railway!)
            drawRect(
                color = Color(0xFF1B5E20), // Green body
                topLeft = Offset(trainX, railY + 2f),
                size = Size(500f, 21f)
            )
            // Red stripe on train
            drawRect(
                color = Color(0xFFB71C1C),
                topLeft = Offset(trainX, railY + 10f),
                size = Size(500f, 4f)
            )
            // Yellow windows
            for (wIndex in 0..12) {
                drawRect(
                    color = Color(0xFFFFEE58),
                    topLeft = Offset(trainX + 20f + wIndex * 38f, railY + 4f),
                    size = Size(14f, 5f)
                )
            }

            // Closed crossing red gate arm
            drawLine(
                color = Color(0xFFD32F2F),
                start = Offset(w * 0.12f, railY - 15f),
                end = Offset(w * 0.88f, railY - 15f),
                strokeWidth = 8f
            )
        }
    }

    // 5. Draw docked river Ferry (when FERRY_BOARD or FERRY_TRANSIT phase)
    if (phase == "FERRY_BOARD" || phase == "FERRY_TRANSIT" || (route.hasFerry && progress in 0.67f..0.76f)) {
        val ferryY = h * 0.28f
        // Huge metal ferry barge sitting in the river
        drawRect(
            color = Color(0xFF546E7A),
            topLeft = Offset(w * 0.18f, ferryY),
            size = Size(w * 0.64f, h * 0.25f)
        )
        // Red bumper border of ferry
        drawRect(
            color = Color(0xFFB71C1C),
            topLeft = Offset(w * 0.18f, ferryY),
            size = Size(w * 0.64f, 15f)
        )
        // Ferry boarding ramp lines
        drawLine(
            color = Color(0xFFECEFF1),
            start = Offset(w * 0.35f, ferryY),
            end = Offset(w * 0.65f, ferryY),
            strokeWidth = 6f
        )
    }
}

private fun DrawScope.drawAITraffic(w: Float, h: Float, traffic: List<AIVehicle>) {
    traffic.forEach { v ->
        val xPos = w * v.x
        val yPos = v.y

        when (v.type) {
            "Rickshaw" -> {
                // Classic Rickshaw Top-Down
                // Passenger yellow/red folding hood
                drawCircle(color = v.color, radius = 16f, center = Offset(xPos, yPos))
                drawRect(color = Color(0xFFFBC02D), topLeft = Offset(xPos - 12f, yPos), size = Size(24f, 15f))
                // Driver seat
                drawCircle(color = Color(0xFF757575), radius = 6f, center = Offset(xPos, yPos - 12f))
                // Front wheel
                drawLine(color = Color(0xFF212121), start = Offset(xPos, yPos - 22f), end = Offset(xPos, yPos - 14f), strokeWidth = 4f)
                // Back axle & wheels
                drawLine(color = Color(0xFF212121), start = Offset(xPos - 15f, yPos + 10f), end = Offset(xPos + 15f, yPos + 10f), strokeWidth = 4f)
            }
            "CNG" -> {
                // Traditional Green Auto Rickshaw
                // Green capsule body
                drawRoundRect(
                    color = v.color,
                    topLeft = Offset(xPos - 15f, yPos - 20f),
                    size = Size(30f, 40f),
                    cornerRadius = CornerRadius(8f, 8f)
                )
                // Yellow metal roof slice
                drawRect(
                    color = Color(0xFFFFEB3B),
                    topLeft = Offset(xPos - 12f, yPos - 12f),
                    size = Size(24f, 22f)
                )
                // Black windshield panel
                drawRect(color = Color(0xFF212121), topLeft = Offset(xPos - 11f, yPos - 17f), size = Size(22f, 5f))
            }
            "Truck" -> {
                // Wooden Bangladeshi cargo truck with lots of painting accents!
                // Blue Cabin front
                drawRoundRect(
                    color = Color(0xFF1565C0),
                    topLeft = Offset(xPos - 22f, yPos - 35f),
                    size = Size(44f, 30f),
                    cornerRadius = CornerRadius(5f, 5f)
                )
                // Windshield
                drawRect(color = Color(0xFFB2EBF2), topLeft = Offset(xPos - 18f, yPos - 31f), size = Size(36f, 8f))
                // Wooden high back cargo box
                drawRect(
                    color = Color(0xFFD84315), // Burnt orange wood
                    topLeft = Offset(xPos - 22f, yPos - 5f),
                    size = Size(44f, 55f)
                )
                // Yellow/green cross patterns on cargo box typical of BD trucks
                drawLine(color = Color(0xFFFFEB3B), start = Offset(xPos - 22f, yPos - 5f), end = Offset(xPos + 22f, yPos + 50f), strokeWidth = 3f)
                drawLine(color = Color(0xFFFFEB3B), start = Offset(xPos + 22f, yPos - 5f), end = Offset(xPos - 22f, yPos + 50f), strokeWidth = 3f)
                drawRect(color = Color(0xFF00E676), topLeft = Offset(xPos - 22f, yPos + 15f), size = Size(44f, 5f))
            }
            "Car" -> {
                // Sedan car
                drawRoundRect(
                    color = v.color,
                    topLeft = Offset(xPos - 18f, yPos - 25f),
                    size = Size(36f, 50f),
                    cornerRadius = CornerRadius(10f, 10f)
                )
                // Windshield
                drawRect(color = Color(0xFFE0F7FA), topLeft = Offset(xPos - 14f, yPos - 15f), size = Size(28f, 7f))
                // Rear window
                drawRect(color = Color(0xFFE0F7FA), topLeft = Offset(xPos - 14f, yPos + 10f), size = Size(28f, 6f))
            }
        }
    }
}

private fun DrawScope.drawPlayerBus(
    w: Float, h: Float,
    xOffset: Float,
    skin: SkinSpec,
    headlightsOn: Boolean,
    ticks: Int,
    speed: Float
) {
    val busX = w * xOffset
    val busY = h * 0.7f // centered vertically near bottom

    // Exhaust smoke particles (animated when moving)
    if (speed > 5f && ticks % 4 == 0) {
        val smokeSize = (ticks % 15).toFloat() + 5f
        drawCircle(
            color = Color(0x33B0BEC5),
            radius = smokeSize,
            center = Offset(busX - 15f, busY + 65f + (ticks % 10))
        )
    }

    // Bus rectangular container body
    val bodyColor = Color(android.graphics.Color.parseColor(skin.bodyColorHex))
    val stripeColor = Color(android.graphics.Color.parseColor(skin.stripeColorHex))
    val accentColor = Color(android.graphics.Color.parseColor(skin.accentColorHex))

    // 1. Shadow of the bus
    drawRect(
        color = Color(0x66000000),
        topLeft = Offset(busX - 26f, busY - 55f),
        size = Size(52f, 120f)
    )

    // 2. Main Bus Body
    drawRoundRect(
        color = bodyColor,
        topLeft = Offset(busX - 24f, busY - 60f),
        size = Size(48f, 120f),
        cornerRadius = CornerRadius(8f, 8f)
    )

    // 3. Side decorative striping (highly characteristic of Bangladeshi buses)
    drawRect(
        color = stripeColor,
        topLeft = Offset(busX - 24f, busY - 30f),
        size = Size(4f, 80f)
    )
    drawRect(
        color = stripeColor,
        topLeft = Offset(busX + 20f, busY - 30f),
        size = Size(4f, 80f)
    )
    // Horizontal aesthetic stripes
    drawRect(
        color = accentColor,
        topLeft = Offset(busX - 20f, busY + 15f),
        size = Size(40f, 10f)
    )

    // 4. Windscreens / Windshield (Front dark cyan glass)
    drawRect(
        color = Color(0xFF006064),
        topLeft = Offset(busX - 20f, busY - 54f),
        size = Size(40f, 15f)
    )
    // Divider
    drawRect(
        color = bodyColor,
        topLeft = Offset(busX - 1f, busY - 54f),
        size = Size(2f, 15f)
    )

    // 5. Windows down the sides
    for (i in 0..4) {
        val winY = busY - 30f + i * 18f
        // Left Window
        drawRect(color = Color(0xAA006064), topLeft = Offset(busX - 22f, winY), size = Size(4f, 12f))
        // Right Window
        drawRect(color = Color(0xAA006064), topLeft = Offset(busX + 18f, winY), size = Size(4f, 12f))
    }

    // 6. Side rearview mirrors
    drawRect(color = accentColor, topLeft = Offset(busX - 29f, busY - 50f), size = Size(5f, 10f))
    drawRect(color = accentColor, topLeft = Offset(busX + 24f, busY - 50f), size = Size(5f, 10f))

    // 7. Headlights (small yellow dots on nose)
    val headlightColor = if (headlightsOn) Color(0xFFFFF176) else Color(0xFFFFD54F)
    drawCircle(color = headlightColor, radius = 3.5f, center = Offset(busX - 16f, busY - 59f))
    drawCircle(color = headlightColor, radius = 3.5f, center = Offset(busX + 16f, busY - 59f))

    // 8. Brake lights (red indicators on tail)
    val braking = speed < 0f || (ticks % 30 < 15 && speed == 0f) // glow when stopped/braking
    val brakeColor = if (braking) Color(0xFFFF1744) else Color(0xFFB71C1C)
    drawRect(color = brakeColor, topLeft = Offset(busX - 18f, busY + 58f), size = Size(6f, 3f))
    drawRect(color = brakeColor, topLeft = Offset(busX + 12f, busY + 58f), size = Size(6f, 3f))
}

private fun DrawScope.drawWeatherEffects(
    w: Float, h: Float,
    weather: String,
    headlights: Boolean,
    wipers: Boolean,
    wiperAngle: Float,
    ticks: Int,
    busXOffset: Float
) {
    val busX = w * busXOffset
    val busY = h * 0.7f

    // 1. Draw Night Headlights light beam sweeps
    if (weather == "Night" && headlights) {
        // Draw dual transparent golden cones projecting forward
        val beamPathL = Path().apply {
            moveTo(busX - 16f, busY - 60f)
            lineTo(busX - 120f, busY - 380f)
            lineTo(busX + 40f, busY - 380f)
            close()
        }
        val beamPathR = Path().apply {
            moveTo(busX + 16f, busY - 60f)
            lineTo(busX - 40f, busY - 380f)
            lineTo(busX + 120f, busY - 380f)
            close()
        }

        drawPath(
            path = beamPathL,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0x99FFF59D), Color(0x00FFF59D)),
                startY = busY - 60f,
                endY = busY - 380f
            )
        )
        drawPath(
            path = beamPathR,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0x99FFF59D), Color(0x00FFF59D)),
                startY = busY - 60f,
                endY = busY - 380f
            )
        )
    }

    // 2. Draw Night translucent dark shade overlay over everything except light cones (simulated simply with dark overlay)
    if (weather == "Night") {
        drawRect(color = Color(0x77000000), size = size)
    }

    // 3. Draw Winter Fog (soft translucent desaturated mist overlay)
    if (weather == "Fog") {
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x88EEEEEE), Color(0xCCB0BEC5)),
                center = Offset(w * 0.5f, h * 0.5f),
                radius = w * 0.75f
            ),
            size = size
        )
    }

    // 4. Draw Monsoon Rain (dynamic slanted lines and splash drops)
    if (weather == "Rain") {
        val random = Random(12345L)
        // Rain droplets falling down
        for (i in 0..45) {
            val rx = random.nextFloat() * w
            val ry = ((ticks * 15f + i * 200f) % (h + 100f)) - 50f
            drawLine(
                color = Color(0x9980DEEA),
                start = Offset(rx, ry),
                end = Offset(rx - 8f, ry + 16f),
                strokeWidth = 2.5f
            )
        }

        // Draw rain ripples on road asphalt
        for (i in 0..5) {
            val rx = w * 0.2f + random.nextFloat() * (w * 0.6f)
            val ry = random.nextFloat() * h
            val size = (ticks % 25).toFloat()
            drawArc(
                color = Color(0x4480DEEA),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = Offset(rx - size/2, ry - size/4),
                size = Size(size, size/2),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
            )
        }
    }

    // 5. Draw Windshield Wipers over the bus cockpit in top-down zoom (or overlay on screen)
    // For extreme retro realism, we draw a mini wiper sweeping over the bus windshield on Canvas!
    rotate(wiperAngle, pivot = Offset(busX, busY - 43f)) {
        // Driver-side wiper arm
        drawLine(
            color = Color(0xFF212121),
            start = Offset(busX - 10f, busY - 43f),
            end = Offset(busX - 10f, busY - 56f),
            strokeWidth = 3.5f
        )
        // Passenger-side wiper arm
        drawLine(
            color = Color(0xFF212121),
            start = Offset(busX + 10f, busY - 43f),
            end = Offset(busX + 10f, busY - 56f),
            strokeWidth = 3.5f
        )
    }
}
