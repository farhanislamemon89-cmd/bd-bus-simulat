package com.example.game

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R

// Midnight Slate Theme Colors
val DeepSlateBg = Color(0xFF121824)
val DarkCardBg = Color(0xFF1E293B)
val GoldAccent = Color(0xFFFF9800)
val EmeraldGreen = Color(0xFF00E676)
val SignalRed = Color(0xFFFF1744)

@Composable
fun MainMenuScreen(viewModel: GameViewModel) {
    val stats by viewModel.playerStats.collectAsState()
    val lang = stats.selectedLanguage

    val infiniteTransition = rememberInfiniteTransition(label = "bannerScale")
    val bannerScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bannerScale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepSlateBg)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 1. Splash Banner Image (Using our beautifully generated local asset!)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp)
                .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_bus_banner),
                contentDescription = "Vibrant Bangladeshi Highway Bus",
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(scaleX = bannerScale, scaleY = bannerScale),
                contentScale = ContentScale.Crop
            )

            // Red/Green Flag overlay corner
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .align(Alignment.TopStart)
                    .padding(12.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF006A4E)),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFF42A41))
                )
            }

            // Dark gradient overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color(0xAA121824), DeepSlateBg),
                            startY = 100f
                        )
                    )
            )

            // Dynamic Money counter overlay
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xDD000000)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.MonetizationOn,
                        contentDescription = "Money Icon",
                        tint = GoldAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "৳${stats.money}",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 2. Beautiful Bangladesh Bus Title Headings
        Text(
            text = GameLocale.tr("app_title", lang),
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Text(
            text = "AAA Simulation Experience • ৫টি মহাকাব্যিক মহাসড়ক",
            fontSize = 12.sp,
            color = Color.LightGray,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
        )

        // 3. Grid-like Main Menu Action Cards
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Career Mode Card (Prominent action!)
            MenuButtonCard(
                title = GameLocale.tr("play_career", lang),
                subtitle = "Board passengers, clear tolls, earn Taka!",
                icon = Icons.Filled.DirectionsBus,
                color = Color(0xFF00E676),
                testTag = "btn_career_mode"
            ) {
                viewModel.navigateTo(GameScreen.RouteSelect)
            }

            // Bus Showroom Garage Card
            MenuButtonCard(
                title = GameLocale.tr("garage", lang),
                subtitle = "Unlock Hino, Scania, Volvo with custom operator skins",
                icon = Icons.Filled.DirectionsCar,
                color = Color(0xFFFF9800),
                testTag = "btn_garage"
            ) {
                viewModel.navigateTo(GameScreen.Garage)
            }

            // High Scores & Achievements
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    MenuSmallButtonCard(
                        title = GameLocale.tr("stats", lang),
                        icon = Icons.Filled.BarChart,
                        color = Color(0xFF00B0FF)
                    ) {
                        viewModel.navigateTo(GameScreen.Stats)
                    }
                }
                Box(modifier = Modifier.weight(1f)) {
                    MenuSmallButtonCard(
                        title = GameLocale.tr("settings", lang),
                        icon = Icons.Filled.Settings,
                        color = Color(0xFF90A4AE)
                    ) {
                        viewModel.navigateTo(GameScreen.Settings)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

@Composable
fun RouteSelectScreen(viewModel: GameViewModel) {
    val stats by viewModel.playerStats.collectAsState()
    val lang = stats.selectedLanguage

    Scaffold(
        topBar = {
            HeaderWithBackButton(
                title = GameLocale.tr("select_route", lang),
                onBack = { viewModel.navigateTo(GameScreen.Menu) }
            )
        },
        containerColor = DeepSlateBg
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding)) {
            // Quick balance card
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCardBg),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Wallet, "Balance", tint = GoldAccent, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Active Budget:", color = Color.Gray, fontSize = 14.sp)
                    }
                    Text("৳${stats.money}", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                }
            }

            // Scrollable route items
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 32.dp)
            ) {
                items(RouteRegistry.routes) { route ->
                    RouteCard(route = route, lang = lang) {
                        viewModel.startRoute(route)
                    }
                }
            }
        }
    }
}

@Composable
fun GarageScreen(viewModel: GameViewModel) {
    val stats by viewModel.playerStats.collectAsState()
    val lang = stats.selectedLanguage

    val selectedBusId by viewModel.garageSelectedBusId.collectAsState()
    val selectedSkinId by viewModel.garageSelectedSkinId.collectAsState()

    val activeBus = BusRegistry.getBus(selectedBusId)
    val activeSkin = activeBus.skins.firstOrNull { it.id == selectedSkinId } ?: activeBus.skins[0]

    val isUnlocked = stats.unlockedBusesJson.split(",").contains(selectedBusId)

    Scaffold(
        topBar = {
            HeaderWithBackButton(
                title = GameLocale.tr("garage", lang),
                onBack = { viewModel.navigateTo(GameScreen.Menu) }
            )
        },
        containerColor = DeepSlateBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Horizontal bus model carousel selector
            Text(
                "SELECT BUS MODEL",
                color = Color.LightGray,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.Start)
                    .padding(horizontal = 24.dp, vertical = 8.dp)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                BusRegistry.buses.forEach { bus ->
                    val isCurrent = selectedBusId == bus.id
                    val ownsModel = stats.unlockedBusesJson.split(",").contains(bus.id)
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isCurrent) Color(0xFF1E3A8A) else DarkCardBg
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .width(180.dp)
                            .clickable { viewModel.setGarageSelectedBus(bus.id) }
                            .border(
                                width = if (isCurrent) 2.dp else 0.dp,
                                color = GoldAccent,
                                shape = RoundedCornerShape(16.dp)
                            )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    bus.name.split(" ")[0], // Brand only
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                if (ownsModel) {
                                    Icon(Icons.Filled.CheckCircle, "Owned", tint = EmeraldGreen, modifier = Modifier.size(16.dp))
                                } else {
                                    Icon(Icons.Filled.Lock, "Locked", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                }
                            }
                            Text(
                                "Max: ${bus.maxSpeed.toInt()} km/h",
                                color = Color.LightGray,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                            Text(
                                if (bus.price == 0) "FREE" else "৳${bus.price}",
                                color = GoldAccent,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Bus Preview Panel displaying active color block reflecting Operator Skins!
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCardBg),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val bodyColor = Color(android.graphics.Color.parseColor(activeSkin.bodyColorHex))
                    val stripeColor = Color(android.graphics.Color.parseColor(activeSkin.stripeColorHex))

                    // Stylized top/isometric abstract bus preview block
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Brush.radialGradient(listOf(Color(0xFF1E293B), Color(0xFF0F172A))))
                    ) {
                        // Drawing miniature abstract bus
                        Card(
                            colors = CardDefaults.cardColors(containerColor = bodyColor),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .width(220.dp)
                                .height(60.dp)
                                .align(Alignment.Center)
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                // Double stripe operator style
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(0.9f)
                                        .height(10.dp)
                                        .align(Alignment.Center)
                                        .background(stripeColor)
                                )
                                // Windscreen glass
                                Box(
                                    modifier = Modifier
                                        .width(30.dp)
                                        .fillMaxHeight()
                                        .align(Alignment.CenterEnd)
                                        .background(Color(0xFF006064))
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        activeBus.name,
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        "Operator Skin: ${activeSkin.name}",
                        color = Color.LightGray,
                        fontSize = 14.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Specs Chart Bar Layout
                    BusSpecProgress("Max Speed", activeBus.maxSpeed / 150f, "${activeBus.maxSpeed.toInt()} km/h")
                    BusSpecProgress("Handling", activeBus.acceleration / 3f, "Extreme")
                    BusSpecProgress("Capacity", activeBus.capacity / 50f, "${activeBus.capacity} seats")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Skin Selector Carousel
            Text(
                "CHOOSE BD OPERATOR SKIN",
                color = Color.LightGray,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.Start)
                    .padding(horizontal = 24.dp)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                activeBus.skins.forEach { skin ->
                    val isSkinSelected = selectedSkinId == skin.id
                    val skinColor = Color(android.graphics.Color.parseColor(skin.bodyColorHex))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkCardBg),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .clickable { viewModel.setGarageSelectedSkin(skin.id) }
                            .border(
                                width = if (isSkinSelected) 2.dp else 0.dp,
                                color = GoldAccent,
                                shape = RoundedCornerShape(12.dp)
                            )
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(skinColor)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(skin.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Unlock/Active Selection CTA Action Button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (isUnlocked) {
                    val isActive = stats.currentBusId == selectedBusId && stats.currentSkinId == selectedSkinId
                    Button(
                        onClick = { viewModel.selectActiveBusAndSkin() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isActive) Color.Gray else EmeraldGreen
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("btn_garage_activate"),
                        enabled = !isActive
                    ) {
                        Text(
                            text = if (isActive) GameLocale.tr("selected", lang) else GameLocale.tr("select", lang),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }
                } else {
                    Button(
                        onClick = { viewModel.buySelectedBus() },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("btn_garage_buy")
                    ) {
                        Text(
                            text = "${GameLocale.tr("buy", lang)}${activeBus.price}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(48.dp))
        }
    }
}

@Composable
fun StatsScreen(viewModel: GameViewModel) {
    val stats by viewModel.playerStats.collectAsState()
    val lang = stats.selectedLanguage

    Scaffold(
        topBar = {
            HeaderWithBackButton(
                title = GameLocale.tr("stats", lang),
                onBack = { viewModel.navigateTo(GameScreen.Menu) }
            )
        },
        containerColor = DeepSlateBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                GameLocale.tr("career_progress", lang),
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold
            )

            // Dynamic Progress Grid
            StatsItemCard(
                label = GameLocale.tr("distance", lang),
                value = String.format("%.1f KM", stats.totalDistanceDrivenKm),
                icon = Icons.Filled.Directions,
                color = Color(0xFF00B0FF)
            )

            StatsItemCard(
                label = GameLocale.tr("fares", lang),
                value = "৳${stats.totalFaresEarned}",
                icon = Icons.Filled.Wallet,
                color = Color(0xFF00E676)
            )

            StatsItemCard(
                label = GameLocale.tr("passengers_total", lang),
                value = "${stats.totalPassengersTransported} Safe Trips",
                icon = Icons.Filled.People,
                color = Color(0xFFFF9800)
            )

            StatsItemCard(
                label = GameLocale.tr("violations", lang),
                value = "${stats.totalViolations} Tickets",
                icon = Icons.Filled.Warning,
                color = Color(0xFFFF1744)
            )

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun SettingsScreen(viewModel: GameViewModel) {
    val stats by viewModel.playerStats.collectAsState()
    val lang = stats.selectedLanguage

    Scaffold(
        topBar = {
            HeaderWithBackButton(
                title = GameLocale.tr("settings", lang),
                onBack = { viewModel.navigateTo(GameScreen.Menu) }
            )
        },
        containerColor = DeepSlateBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Language Selection
            SettingsSectionHeader(GameLocale.tr("language", lang))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                LanguageButton(label = "English", active = lang == "en", modifier = Modifier.weight(1f)) {
                    viewModel.setLanguage("en")
                }
                LanguageButton(label = "বাংলা", active = lang == "bn", modifier = Modifier.weight(1f)) {
                    viewModel.setLanguage("bn")
                }
            }

            // Controls Selection
            SettingsSectionHeader(GameLocale.tr("controls", lang))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ControlButton("Buttons", stats.controlType == "Buttons", modifier = Modifier.weight(1f)) {
                    viewModel.setControls("Buttons")
                }
                ControlButton("Wheel", stats.controlType == "Steering Wheel", modifier = Modifier.weight(1f)) {
                    viewModel.setControls("Steering Wheel")
                }
            }

            // SFX Volume
            SettingsSectionHeader(GameLocale.tr("volume", lang))
            Card(colors = CardDefaults.cardColors(containerColor = DarkCardBg)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Icon(Icons.Filled.VolumeUp, "Volume", tint = Color.LightGray)
                        Text("${(stats.soundVolume * 100).toInt()}%", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = stats.soundVolume,
                        onValueChange = { viewModel.setSoundVolume(it) },
                        colors = SliderDefaults.colors(
                            thumbColor = GoldAccent,
                            activeTrackColor = GoldAccent
                        )
                    )
                }
            }

            // Graphics Level
            SettingsSectionHeader(GameLocale.tr("graphics", lang))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                listOf("Low", "Medium", "Ultra").forEach { quality ->
                    val isActive = stats.graphicsQuality == quality
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isActive) Color(0xFF1E3A8A) else DarkCardBg
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { viewModel.setGraphics(quality) }
                            .border(width = if (isActive) 1.dp else 0.dp, color = GoldAccent, shape = RoundedCornerShape(8.dp)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = quality,
                            color = Color.White,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

// ----------------------------------------------------
// UI HELPERS & COMPOSABLE SUBCOMPONENTS
// ----------------------------------------------------

@Composable
fun HeaderWithBackButton(title: String, onBack: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .clip(CircleShape)
                .background(DarkCardBg)
                .testTag("btn_back")
        ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back Button", tint = Color.White)
        }
        Spacer(modifier = Modifier.width(16.dp))
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun RouteCard(route: RouteSpec, lang: String, onStart: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkCardBg),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clickable { onStart() }
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = GameLocale.tr(route.nameKey, lang),
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(0.8f)
                )
                // Weather Icon Badge
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0xFF334155))
                        .padding(6.dp)
                ) {
                    Icon(
                        imageVector = when (route.defaultWeather) {
                            "Rain" -> Icons.Filled.Cloud
                            "Fog" -> Icons.Filled.FilterDrama
                            "Night" -> Icons.Filled.Brightness2
                            else -> Icons.Filled.WbSunny
                        },
                        contentDescription = "Weather",
                        tint = GoldAccent,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Sub info lines
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Distance: ${route.distanceKm} km", color = Color.LightGray, fontSize = 13.sp)
                Text(
                    "Est. Reward: ৳${route.rewardTaka}",
                    color = EmeraldGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            Divider(color = Color(0x22FFFFFF), modifier = Modifier.padding(vertical = 12.dp))

            // Highlights
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (route.hasBridge) {
                    RouteChip("Bridge: ${route.bridgeName}", Icons.Filled.Architecture, Color(0xFF03A9F4))
                }
                if (route.hasFerry) {
                    RouteChip("Padma Ferry", Icons.Filled.AirportShuttle, Color(0xFFFF9800))
                }
                if (route.hasToll) {
                    RouteChip("Toll Gate", Icons.Filled.Payment, Color(0xFFE91E63))
                }
                if (route.hasRailwayCrossing) {
                    RouteChip("Train tracks", Icons.Filled.Tram, Color(0xFF9C27B0))
                }
            }
        }
    }
}

@Composable
fun RouteChip(label: String, icon: ImageVector, color: Color) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, label, tint = color, modifier = Modifier.size(13.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(label, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun BusSpecProgress(label: String, value: Float, textVal: String) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = Color.Gray, fontSize = 13.sp)
            Text(textVal, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(
            progress = { value },
            color = GoldAccent,
            trackColor = Color(0xFF334155),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp)
                .height(6.dp)
                .clip(CircleShape)
        )
    }
}

@Composable
fun MenuButtonCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkCardBg),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, title, tint = color, modifier = Modifier.size(28.dp))
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Color.LightGray, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun MenuSmallButtonCard(
    title: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkCardBg),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, title, tint = color, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun StatsItemCard(label: String, value: String, icon: ImageVector, color: Color) {
    Card(colors = CardDefaults.cardColors(containerColor = DarkCardBg)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, label, tint = color, modifier = Modifier.size(22.dp))
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text(label, color = Color.LightGray, fontSize = 15.sp)
            }
            Text(value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

@Composable
fun SettingsSectionHeader(title: String) {
    Text(
        title.uppercase(),
        color = Color.LightGray,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(bottom = 6.dp)
    )
}

@Composable
fun LanguageButton(label: String, active: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (active) Color(0xFF1E3A8A) else DarkCardBg
        ),
        modifier = modifier
            .clickable { onClick() }
            .border(width = if (active) 1.dp else 0.dp, color = GoldAccent, shape = RoundedCornerShape(12.dp)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(
            text = label,
            color = Color.White,
            fontSize = 15.sp,
            textAlign = TextAlign.Center,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        )
    }
}

@Composable
fun ControlButton(label: String, active: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (active) Color(0xFF1E3A8A) else DarkCardBg
        ),
        modifier = modifier
            .clickable { onClick() }
            .border(width = if (active) 1.dp else 0.dp, color = GoldAccent, shape = RoundedCornerShape(12.dp)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(
            text = label,
            color = Color.White,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp)
        )
    }
}
