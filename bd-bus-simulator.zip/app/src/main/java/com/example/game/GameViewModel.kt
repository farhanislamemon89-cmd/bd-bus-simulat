package com.example.game

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.db.AppDatabase
import com.example.db.PlayerStats
import com.example.db.PlayerStatsDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed class GameScreen {
    object Splash : GameScreen()
    object Menu : GameScreen()
    object RouteSelect : GameScreen()
    object Garage : GameScreen()
    object Stats : GameScreen()
    object Settings : GameScreen()
    object Driving : GameScreen()
}

class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val statsDao = db.playerStatsDao()

    // Screen navigation state
    private val _currentScreen = MutableStateFlow<GameScreen>(GameScreen.Splash)
    val currentScreen: StateFlow<GameScreen> = _currentScreen.asStateFlow()

    // Player statistical state
    private val _playerStats = MutableStateFlow(PlayerStats())
    val playerStats: StateFlow<PlayerStats> = _playerStats.asStateFlow()

    // Selected state in Garage
    private val _garageSelectedBusId = MutableStateFlow("Ashok Leyland")
    val garageSelectedBusId: StateFlow<String> = _garageSelectedBusId.asStateFlow()

    private val _garageSelectedSkinId = MutableStateFlow("BRTC")
    val garageSelectedSkinId: StateFlow<String> = _garageSelectedSkinId.asStateFlow()

    // Driving Simulation Live States
    private val _activeRoute = MutableStateFlow<RouteSpec?>(null)
    val activeRoute: StateFlow<RouteSpec?> = _activeRoute.asStateFlow()

    private val _activeSpeed = MutableStateFlow(0f) // km/h
    val activeSpeed: StateFlow<Float> = _activeSpeed.asStateFlow()

    private val _activeRpm = MutableStateFlow(800f) // engine RPM
    val activeRpm: StateFlow<Float> = _activeRpm.asStateFlow()

    private val _currentGear = MutableStateFlow("P") // P, R, N, D
    val currentGear: StateFlow<String> = _currentGear.asStateFlow()

    private val _steeringAngle = MutableStateFlow(0f) // -360 to 360 degrees
    val steeringAngle: StateFlow<Float> = _steeringAngle.asStateFlow()

    private val _fuel = MutableStateFlow(100f) // 0 to 100%
    val fuel: StateFlow<Float> = _fuel.asStateFlow()

    private val _damage = MutableStateFlow(0f) // 0 to 100%
    val damage: StateFlow<Float> = _damage.asStateFlow()

    private val _dirt = MutableStateFlow(0f) // 0 to 100%
    val dirt: StateFlow<Float> = _dirt.asStateFlow()

    private val _activePassengers = MutableStateFlow(0)
    val activePassengers: StateFlow<Int> = _activePassengers.asStateFlow()

    private val _doorOpen = MutableStateFlow(true) // starts open at terminal
    val doorOpen: StateFlow<Boolean> = _doorOpen.asStateFlow()

    private val _headlightsOn = MutableStateFlow(false)
    val headlightsOn: StateFlow<Boolean> = _headlightsOn.asStateFlow()

    private val _wipersOn = MutableStateFlow(false)
    val wipersOn: StateFlow<Boolean> = _wipersOn.asStateFlow()

    // Driving Milestone / Phase Status
    // "BOARDING", "DRIVING", "TOLL_PLAZA", "RAILWAY_GATE", "FERRY_BOARD", "FERRY_TRANSIT", "FERRY_LAND", "DESTINATION_APPROACH", "COMPLETED"
    private val _drivePhase = MutableStateFlow("BOARDING")
    val drivePhase: StateFlow<String> = _drivePhase.asStateFlow()

    private val _driveProgress = MutableStateFlow(0f) // 0.0 to 1.0 (relative highway progress)
    val driveProgress: StateFlow<Float> = _driveProgress.asStateFlow()

    // Live gameplay notifications
    private val _gameNotification = MutableStateFlow<String?>(null)
    val gameNotification: StateFlow<String?> = _gameNotification.asStateFlow()

    init {
        // Observe player statistics from Room
        viewModelScope.launch(Dispatchers.IO) {
            statsDao.getPlayerStats().collectLatest { stats ->
                if (stats == null) {
                    // Seed initial stats if empty
                    val initialStats = PlayerStats()
                    statsDao.insertOrUpdate(initialStats)
                    _playerStats.value = initialStats
                } else {
                    _playerStats.value = stats
                    _garageSelectedBusId.value = stats.currentBusId
                    _garageSelectedSkinId.value = stats.currentSkinId
                }
            }
        }
    }

    // Navigation triggers
    fun navigateTo(screen: GameScreen) {
        _currentScreen.value = screen
        _gameNotification.value = null
    }

    // Garage actions
    fun setGarageSelectedBus(busId: String) {
        _garageSelectedBusId.value = busId
        val bus = BusRegistry.getBus(busId)
        // Default skin selection for the bus
        _garageSelectedSkinId.value = bus.skins.firstOrNull()?.id ?: ""
    }

    fun setGarageSelectedSkin(skinId: String) {
        _garageSelectedSkinId.value = skinId
    }

    fun buySelectedBus() {
        val busId = _garageSelectedBusId.value
        val bus = BusRegistry.getBus(busId)
        val currentStats = _playerStats.value
        
        if (currentStats.money >= bus.price) {
            viewModelScope.launch(Dispatchers.IO) {
                val unlockedList = currentStats.unlockedBusesJson.split(",").toMutableList()
                if (!unlockedList.contains(busId)) {
                    unlockedList.add(busId)
                    val updatedStats = currentStats.copy(
                        money = currentStats.money - bus.price,
                        unlockedBusesJson = unlockedList.joinToString(","),
                        currentBusId = busId,
                        currentSkinId = _garageSelectedSkinId.value
                    )
                    statsDao.insertOrUpdate(updatedStats)
                    showNotification("Unlocked: ${bus.name}!")
                }
            }
        } else {
            showNotification("Insufficient Money!")
        }
    }

    fun selectActiveBusAndSkin() {
        val busId = _garageSelectedBusId.value
        val skinId = _garageSelectedSkinId.value
        val currentStats = _playerStats.value
        
        viewModelScope.launch(Dispatchers.IO) {
            val updatedStats = currentStats.copy(
                currentBusId = busId,
                currentSkinId = skinId
            )
            statsDao.insertOrUpdate(updatedStats)
            showNotification("Bus set as Active!")
        }
    }

    // Settings adjustments
    fun setLanguage(langCode: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = _playerStats.value.copy(selectedLanguage = langCode)
            statsDao.insertOrUpdate(updated)
        }
    }

    fun setControls(controlType: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = _playerStats.value.copy(controlType = controlType)
            statsDao.insertOrUpdate(updated)
        }
    }

    fun setSoundVolume(volume: Float) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = _playerStats.value.copy(soundVolume = volume)
            statsDao.insertOrUpdate(updated)
        }
    }

    fun setGraphics(quality: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = _playerStats.value.copy(graphicsQuality = quality)
            statsDao.insertOrUpdate(updated)
        }
    }

    // Driving loop lifecycle
    fun startRoute(route: RouteSpec) {
        _activeRoute.value = route
        _fuel.value = 100f
        _damage.value = 0f
        _dirt.value = 0f
        _activeSpeed.value = 0f
        _activeRpm.value = 800f
        _currentGear.value = "P"
        _steeringAngle.value = 0f
        _activePassengers.value = 0
        _doorOpen.value = true
        _drivePhase.value = "BOARDING"
        _driveProgress.value = 0f
        _currentScreen.value = GameScreen.Driving
        _gameNotification.value = GameLocale.tr("boarding", _playerStats.value.selectedLanguage)
    }

    fun completeBoarding() {
        if (_drivePhase.value == "BOARDING") {
            val bus = BusRegistry.getBus(_playerStats.value.currentBusId)
            _activePassengers.value = bus.capacity
            _doorOpen.value = false
            _currentGear.value = "N"
            _drivePhase.value = "DRIVING"
            showNotification(GameLocale.tr("boarding_done", _playerStats.value.selectedLanguage))
        }
    }

    fun applySteering(angle: Float) {
        _steeringAngle.value = angle.coerceIn(-360f, 360f)
    }

    fun setGear(gear: String) {
        if (gear in listOf("P", "R", "N", "D")) {
            _currentGear.value = gear
            if (gear == "P") {
                _activeSpeed.value = 0f
                _activeRpm.value = 800f
            }
        }
    }

    fun toggleDoor() {
        if (_activeSpeed.value == 0f) {
            _doorOpen.value = !_doorOpen.value
        } else {
            showNotification("Stop the bus first!")
        }
    }

    fun toggleHeadlights() {
        _headlightsOn.value = !_headlightsOn.value
    }

    fun toggleWipers() {
        _wipersOn.value = !_wipersOn.value
    }

    // Engine simulation ticks (called from screen LaunchedEffect at 60Hz)
    fun updateSimulationTick(accFactor: Float, brakeFactor: Float) {
        val route = _activeRoute.value ?: return
        val bus = BusRegistry.getBus(_playerStats.value.currentBusId)
        val gear = _currentGear.value
        var speed = _activeSpeed.value
        var rpm = _activeRpm.value
        var progress = _driveProgress.value

        // Phase check - locks speed when waiting at obstacles
        val blockMovement = when (_drivePhase.value) {
            "BOARDING", "FERRY_TRANSIT", "COMPLETED" -> true
            "TOLL_PLAZA" -> speed <= 0f // must fully stop at toll to pay and clear
            "RAILWAY_GATE" -> true // must wait for train
            "FERRY_BOARD" -> false // driving onto the ferry
            else -> false
        }

        if (blockMovement) {
            speed = (speed - 5f).coerceAtLeast(0f)
            rpm = (800f + speed * 15f).coerceAtMost(3000f)
            _activeSpeed.value = speed
            _activeRpm.value = rpm
            if (_drivePhase.value == "FERRY_TRANSIT") {
                simulateFerryTransitTick()
            }
            return
        }

        // Steer factor slide/slip based on rain
        val isRain = route.defaultWeather == "Rain"
        val surfaceFriction = if (isRain) 0.75f else 1.0f

        // Fuel consumption
        if (speed > 5f) {
            _fuel.value = (_fuel.value - (0.002f / bus.fuelEfficiency)).coerceAtLeast(0f)
            if (_fuel.value <= 0f) {
                speed = (speed - 1f).coerceAtLeast(0f)
                showNotification("OUT OF FUEL! Stop at nearest pump.")
            }
        }

        // Dirt accumulation in rain
        if (isRain && speed > 10f) {
            _dirt.value = (_dirt.value + 0.05f).coerceAtMost(100f)
        }

        // Acceleration and braking physics
        if (gear == "D" && _fuel.value > 0f) {
            if (accFactor > 0f) {
                val accelRate = bus.acceleration * accFactor * surfaceFriction * 0.12f
                speed = (speed + accelRate).coerceAtMost(bus.maxSpeed)
                rpm = (800f + speed * 22f).coerceAtMost(4500f)
            } else {
                speed = (speed - 0.2f).coerceAtLeast(0f) // coasting deceleration
                rpm = (rpm - 15f).coerceAtLeast(800f)
            }
        } else if (gear == "R" && _fuel.value > 0f) {
            if (accFactor > 0f) {
                speed = (speed - bus.acceleration * 0.05f).coerceAtMost(30f) // negative speed for reverse
                rpm = (800f + Math.abs(speed) * 30f).coerceAtMost(2500f)
            } else {
                speed = (speed + 0.3f).coerceAtMost(0f)
                rpm = (rpm - 15f).coerceAtLeast(800f)
            }
        } else {
            // Neutral/Park coasting
            val frictionDecel = 0.4f
            if (speed > 0f) speed = (speed - frictionDecel).coerceAtLeast(0f)
            else if (speed < 0f) speed = (speed + frictionDecel).coerceAtMost(0f)
            rpm = (rpm - 25f).coerceAtLeast(800f)
        }

        // Active braking
        if (brakeFactor > 0f) {
            val brakeRate = 1.2f * brakeFactor
            if (speed > 0f) speed = (speed - brakeRate).coerceAtLeast(0f)
            else if (speed < 0f) speed = (speed + brakeRate).coerceAtMost(0f)
            rpm = (rpm - 40f).coerceAtLeast(800f)
        }

        // Cap values
        _activeSpeed.value = speed
        _activeRpm.value = rpm

        // Drive progress calculation
        if (Math.abs(speed) > 0.1f) {
            val deltaProgress = ((Math.abs(speed) / (route.distanceKm * 3600f)) * 10f).toFloat() // scaled for enjoyable quick gameplay
            progress = (progress + deltaProgress).coerceAtMost(1.0f)
            _driveProgress.value = progress

            // Career stats accumulate locally during driving
            viewModelScope.launch(Dispatchers.IO) {
                val currentStats = _playerStats.value
                val addedDistance = (Math.abs(speed) / 3600f) * 0.1f
                statsDao.insertOrUpdate(currentStats.copy(
                    totalDistanceDrivenKm = currentStats.totalDistanceDrivenKm + addedDistance
                ))
            }
        }

        // Highway phase trigger points based on progress
        checkPhaseTriggers(progress, route, speed)
    }

    private var ferryTransitCounter = 0
    private fun simulateFerryTransitTick() {
        ferryTransitCounter++
        if (ferryTransitCounter > 400) { // roughly 6-7 seconds crossing cutscene
            _drivePhase.value = "DRIVING"
            ferryTransitCounter = 0
            showNotification(GameLocale.tr("ferry_boarding", _playerStats.value.selectedLanguage))
        }
    }

    private var checkedToll = false
    private var checkedCrossing = false
    private var checkedFerry = false

    private fun checkPhaseTriggers(progress: Float, route: RouteSpec, speed: Float) {
        val lang = _playerStats.value.selectedLanguage

        // 1. Toll plaza trigger (at 25% progress if enabled)
        if (route.hasToll && progress in 0.24f..0.27f && !checkedToll) {
            if (_drivePhase.value == "DRIVING") {
                _drivePhase.value = "TOLL_PLAZA"
                showNotification(GameLocale.tr("toll_plaza", lang))
            }
        }

        // 2. Railway crossing trigger (at 50% progress if enabled)
        if (route.hasRailwayCrossing && progress in 0.49f..0.52f && !checkedCrossing) {
            if (_drivePhase.value == "DRIVING") {
                _drivePhase.value = "RAILWAY_GATE"
                showNotification(GameLocale.tr("railway_gate", lang))
                // Auto lift gate after some time
                viewModelScope.launch {
                    kotlinx.coroutines.delay(5000)
                    _drivePhase.value = "DRIVING"
                    checkedCrossing = true
                }
            }
        }

        // 3. Ferry boarding (at 70% progress if enabled)
        if (route.hasFerry && progress in 0.69f..0.72f && !checkedFerry) {
            if (_drivePhase.value == "DRIVING") {
                _drivePhase.value = "FERRY_BOARD"
                showNotification(GameLocale.tr("ferry_boarding", lang))
            }
        }

        // 4. Destination Terminal Approach (at 92% progress)
        if (progress >= 0.92f && progress < 0.99f && _drivePhase.value == "DRIVING") {
            _drivePhase.value = "DESTINATION_APPROACH"
            showNotification(GameLocale.tr("terminal_arrival", lang))
        }

        // 5. Route Complete (at 100% progress)
        if (progress >= 1.0f && _drivePhase.value == "DESTINATION_APPROACH") {
            _drivePhase.value = "COMPLETED"
            _activeSpeed.value = 0f
            _activeRpm.value = 800f
            _currentGear.value = "P"
            _doorOpen.value = true

            // Pay rewards & update Room career stats!
            val reward = route.rewardTaka
            viewModelScope.launch(Dispatchers.IO) {
                val currentStats = _playerStats.value
                val updatedStats = currentStats.copy(
                    money = currentStats.money + reward,
                    totalFaresEarned = currentStats.totalFaresEarned + reward,
                    totalPassengersTransported = currentStats.totalPassengersTransported + _activePassengers.value
                )
                statsDao.insertOrUpdate(updatedStats)
            }
            showNotification("${GameLocale.tr("arrival_payout", lang)} +৳$reward")
        }
    }

    // Interactive highway action buttons
    fun payTollPlaza() {
        val stats = _playerStats.value
        if (_drivePhase.value == "TOLL_PLAZA" && stats.money >= 100) {
            viewModelScope.launch(Dispatchers.IO) {
                statsDao.updateMoney(stats.money - 100)
            }
            _drivePhase.value = "DRIVING"
            checkedToll = true
            showNotification("Toll Paid! Gate Opened.")
        } else {
            showNotification("Insufficient balance for Toll!")
        }
    }

    fun driveOntoFerry() {
        if (_drivePhase.value == "FERRY_BOARD") {
            _drivePhase.value = "FERRY_TRANSIT"
            _activeSpeed.value = 0f
            _activeRpm.value = 800f
            showNotification(GameLocale.tr("ferry_crossing", _playerStats.value.selectedLanguage))
            checkedFerry = true
        }
    }

    // Refuel / Repair during transit or menus
    fun refuelBusAtPump() {
        val currentMoney = _playerStats.value.money
        if (currentMoney >= 250) {
            _fuel.value = 100f
            viewModelScope.launch(Dispatchers.IO) {
                statsDao.updateMoney(currentMoney - 250)
            }
            showNotification(GameLocale.tr("refuel_success", _playerStats.value.selectedLanguage) + "250")
        } else {
            showNotification("Not enough cash (৳250 required)!")
        }
    }

    fun repairBusAtWorkshop() {
        val currentMoney = _playerStats.value.money
        if (currentMoney >= 300) {
            _damage.value = 0f
            viewModelScope.launch(Dispatchers.IO) {
                statsDao.updateMoney(currentMoney - 300)
            }
            showNotification(GameLocale.tr("repair_success", _playerStats.value.selectedLanguage) + "300")
        } else {
            showNotification("Not enough cash (৳300 required)!")
        }
    }

    fun washBusAtStation() {
        val currentMoney = _playerStats.value.money
        if (currentMoney >= 50) {
            _dirt.value = 0f
            viewModelScope.launch(Dispatchers.IO) {
                statsDao.updateMoney(currentMoney - 50)
            }
            showNotification(GameLocale.tr("wash_success", _playerStats.value.selectedLanguage))
        } else {
            showNotification("Not enough cash (৳50 required)!")
        }
    }

    fun triggerCollisionCrash() {
        // decreases condition, charges fine
        val currentDmg = _damage.value
        val nextDmg = (currentDmg + 20f).coerceAtMost(100f)
        _damage.value = nextDmg

        val currentMoney = _playerStats.value.money
        viewModelScope.launch(Dispatchers.IO) {
            val stats = _playerStats.value
            statsDao.insertOrUpdate(stats.copy(
                money = (currentMoney - 150).coerceAtLeast(0),
                totalViolations = stats.totalViolations + 1
            ))
        }
        showNotification(GameLocale.tr("fine_crash", _playerStats.value.selectedLanguage))
    }

    fun triggerSpeedingFine() {
        val currentMoney = _playerStats.value.money
        viewModelScope.launch(Dispatchers.IO) {
            val stats = _playerStats.value
            statsDao.insertOrUpdate(stats.copy(
                money = (currentMoney - 200).coerceAtLeast(0),
                totalViolations = stats.totalViolations + 1
            ))
        }
        showNotification(GameLocale.tr("fine_speed", _playerStats.value.selectedLanguage))
    }

    // Helper notification
    private fun showNotification(msg: String) {
        _gameNotification.value = msg
        viewModelScope.launch {
            kotlinx.coroutines.delay(4000)
            if (_gameNotification.value == msg) {
                _gameNotification.value = null
            }
        }
    }
}
