package com.example.game

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun GamePlayScreen(viewModel: GameViewModel) {
    val route = viewModel.activeRoute.collectAsState().value ?: return
    val speed by viewModel.activeSpeed.collectAsState()
    val rpm by viewModel.activeRpm.collectAsState()
    val gear by viewModel.currentGear.collectAsState()
    val steeringAngle by viewModel.steeringAngle.collectAsState()
    val fuel by viewModel.fuel.collectAsState()
    val damage by viewModel.damage.collectAsState()
    val dirt by viewModel.dirt.collectAsState()
    val passengers by viewModel.activePassengers.collectAsState()
    val doorOpen by viewModel.doorOpen.collectAsState()
    val headlights by viewModel.headlightsOn.collectAsState()
    val wipers by viewModel.wipersOn.collectAsState()
    val phase by viewModel.drivePhase.collectAsState()
    val progress by viewModel.driveProgress.collectAsState()
    val notification by viewModel.gameNotification.collectAsState()
    val stats by viewModel.playerStats.collectAsState()

    val lang = stats.selectedLanguage
    val scope = rememberCoroutineScope()

    // Holding pedal states
    var isGasPressed by remember { mutableStateOf(false) }
    var isBrakePressed by remember { mutableStateOf(false) }

    // Driving horn flash overlay animations
    var hornFlashCount by remember { mutableStateOf(0) }
    var hydraulicFlashCount by remember { mutableStateOf(0) }

    // Steer Drag Accumulator
    var cumulatedDragAngle by remember { mutableStateOf(0f) }

    // Game loop simulation trigger at 60Hz
    LaunchedEffect(isGasPressed, isBrakePressed, phase) {
        while (true) {
            val acc = if (isGasPressed) 1f else 0f
            val brake = if (isBrakePressed) 1f else 0f
            viewModel.updateSimulationTick(acc, brake)
            delay(16) // 60 FPS update
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(DeepSlateBg)) {
        
        // 1. GAMEPLAY SCENERY CANVAS VIEW
        GameCanvasView(
            viewModel = viewModel,
            modifier = Modifier.fillMaxSize()
        )

        // 2. TOP HUD LAYER (Progress, exit, stats)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Exit button
                IconButton(
                    onClick = { viewModel.navigateTo(GameScreen.Menu) },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0xDD000000))
                        .testTag("btn_drive_exit")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Quit Driving", tint = Color.White)
                }

                // Route status info
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xDD000000)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                        Text(
                            text = "${route.startCity} ➔ ${route.endCity}",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = GameLocale.tr(route.nameKey, lang),
                            color = GoldAccent,
                            fontSize = 10.sp
                        )
                    }
                }

                // Live money overlay
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xDD000000)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "৳${stats.money}",
                        color = EmeraldGreen,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Highway Progress Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.DirectionsBus, "Bus Icon", tint = GoldAccent, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    color = EmeraldGreen,
                    trackColor = Color(0x66FFFFFF),
                    modifier = Modifier
                        .weight(1f)
                        .height(6.dp)
                        .clip(CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "${(progress * 100).toInt()}%",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }

        // 3. LIVE HUD NOTIFICATION / ANNOUNCEMENTS POPUP
        AnimatedVisibility(
            visible = notification != null,
            enter = fadeIn() + slideInVertically(),
            exit = fadeOut() + slideOutVertically(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 110.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xEE1E293B)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.padding(horizontal = 32.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Info, "Alert", tint = GoldAccent, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = notification ?: "",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // 4. FLASHING HORNING GRAPHIC OVERLAYS
        if (hornFlashCount > 0) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x33FFF59D)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "PEEP! PEEP!",
                    color = Color.Black,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 32.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .background(GoldAccent, RoundedCornerShape(16.dp))
                        .padding(24.dp)
                )
            }
        }
        if (hydraulicFlashCount > 0) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x33FF5252)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "♫ PAM-POM-PAAA! (HYDRAULIC HORN) ♫",
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 22.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .background(SignalRed, RoundedCornerShape(16.dp))
                        .padding(24.dp)
                )
            }
        }

        // 5. INTERACTIVE DRIVING ACTIONS OVERLAY (Phases blocker)
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(bottom = 120.dp)
        ) {
            when (phase) {
                "BOARDING" -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xEE111827)),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.width(300.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                "DHAKA TERMINAL GATE",
                                color = GoldAccent,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                if (passengers == 0) "Open Door to start passenger boarding" else "Passengers: $passengers / ${route.distanceKm.toInt() / 6} boarded",
                                color = Color.White,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            if (passengers == 0) {
                                Button(
                                    onClick = { viewModel.completeBoarding() },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth().testTag("btn_action_board")
                                ) {
                                    Text("OPEN DOOR & BOARD", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
                "TOLL_PLAZA" -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xEE111827)),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.width(300.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                "COMILLA TOLL BOOTH",
                                color = SignalRed,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "Stop the bus fully inside the Toll Plaza and pay ৳100 to raise the barrier.",
                                color = Color.White,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { viewModel.payTollPlaza() },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().testTag("btn_action_pay_toll"),
                                enabled = speed <= 0f // must fully stop
                            ) {
                                Text(
                                    text = if (speed > 0f) "STOP FULLY TO PAY" else "PAY TOLL (৳100)",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
                "FERRY_BOARD" -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xEE111827)),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.width(300.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                "PADMA RIVER DOCK",
                                color = GoldAccent,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "Carefully drive onto the docked Ferry boat deck, then dock the bus.",
                                color = Color.White,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { viewModel.driveOntoFerry() },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().testTag("btn_action_ferry_dock")
                            ) {
                                Text("DOCK ON FERRY", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                "FERRY_TRANSIT" -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xEE1E293B)),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.width(300.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(color = GoldAccent)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                "Crossing river via Ferry...",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Take a tea break! Local bhatiali music is playing.",
                                color = Color.LightGray,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
                "COMPLETED" -> {
                    // Massive congratulation overlay card with route summaries!
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkCardBg),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .width(340.dp)
                            .padding(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Filled.CheckCircle, "Success", tint = EmeraldGreen, modifier = Modifier.size(56.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                "ARRIVED SAFELY!",
                                color = Color.White,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                "Route completed successfully at terminal.",
                                color = Color.LightGray,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )

                            Divider(color = Color(0x22FFFFFF), modifier = Modifier.padding(vertical = 16.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Passengers Delivered:", color = Color.Gray, fontSize = 13.sp)
                                Text("$passengers Safely", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Highway Reward:", color = Color.Gray, fontSize = 13.sp)
                                Text("+৳${route.rewardTaka}", color = EmeraldGreen, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                            }

                            Spacer(modifier = Modifier.height(24.dp))

                            Button(
                                onClick = { viewModel.navigateTo(GameScreen.Menu) },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth().testTag("btn_drive_complete_return")
                            ) {
                                Text("COLLECT FARES & EXIT", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // 6. BOTTOM COCKPIT HUD LAYER (Speeds, controls, steering wheel, pedals)
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xDD0F172A)),
            shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Row 1: Steering Wheel (Left) & Gauges (Center) & Pedals (Right)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left Column: Interactive Steering Wheel
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF1E293B))
                                .rotate(steeringAngle)
                                .pointerInput(Unit) {
                                    detectDragGestures(
                                        onDragStart = { cumulatedDragAngle = 0f },
                                        onDragEnd = { viewModel.applySteering(0f) }, // auto-center
                                        onDrag = { change, dragAmount ->
                                            change.consume()
                                            // horizontal drag alters steer angle
                                            cumulatedDragAngle += dragAmount.x * 0.8f
                                            viewModel.applySteering(cumulatedDragAngle)
                                        }
                                    )
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            // Circular layout mimicking a bus steering wheel spokes
                            Box(
                                modifier = Modifier
                                    .fillMaxSize(0.9f)
                                    .border(6.dp, Color.Black, CircleShape)
                            )
                            // Spokes
                            Box(modifier = Modifier.width(6.dp).fillMaxHeight(0.85f).background(Color.Black))
                            Box(modifier = Modifier.height(6.dp).fillMaxWidth(0.85f).background(Color.Black))
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(Color.Gray)
                                    .border(2.dp, Color.Black, CircleShape)
                            )
                        }
                        Text(
                            text = "STEER WHEEL",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Gray,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    // Center Column: Dashboard Gauges & Gear Indicator
                    Column(
                        modifier = Modifier.width(140.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Digital Speedometer readouts
                        Text(
                            text = "${speed.toInt().coerceAtLeast(0)}",
                            color = if (speed > 100) SignalRed else Color.White,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "KM/H",
                            color = Color.LightGray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // Dynamic indicators
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            DashboardGlowIndicator("F", fuel / 100f, if (fuel < 20f) SignalRed else EmeraldGreen)
                            DashboardGlowIndicator("D", (100f - damage) / 100f, if (damage > 70f) SignalRed else GoldAccent)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Multi-action status toggles (Lights, Wipers, Door)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            DashboardSmallToggle(Icons.Filled.Lightbulb, headlights) {
                                viewModel.toggleHeadlights()
                            }
                            DashboardSmallToggle(Icons.Filled.CloudQueue, wipers) {
                                viewModel.toggleWipers()
                            }
                            DashboardSmallToggle(Icons.Filled.MeetingRoom, doorOpen) {
                                viewModel.toggleDoor()
                            }
                        }
                    }

                    // Right Column: Gas & Brake Pedals (Detecting long presses)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Brake Pedal
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isBrakePressed) Color(0xFFFF5252) else Color(0x33FF5252)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .width(46.dp)
                                .height(95.dp)
                                .border(width = 1.dp, color = Color(0xFFFF5252), shape = RoundedCornerShape(8.dp))
                                .pointerInput(Unit) {
                                    detectTapGestures(
                                        onPress = {
                                            try {
                                                isBrakePressed = true
                                                awaitRelease()
                                                isBrakePressed = false
                                            } catch (e: Exception) {
                                                isBrakePressed = false
                                            }
                                        }
                                    )
                                }
                                .testTag("btn_drive_brake")
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize().padding(4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("B\nR\nA\nK\nE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp, textAlign = TextAlign.Center)
                                Icon(Icons.Filled.Download, "Brake Icon", tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                        }

                        // Gas Pedal
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isGasPressed) Color(0xFF00E676) else Color(0x3300E676)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .width(46.dp)
                                .height(95.dp)
                                .border(width = 1.dp, color = Color(0xFF00E676), shape = RoundedCornerShape(8.dp))
                                .pointerInput(Unit) {
                                    detectTapGestures(
                                        onPress = {
                                            try {
                                                isGasPressed = true
                                                awaitRelease()
                                                isGasPressed = false
                                            } catch (e: Exception) {
                                                isGasPressed = false
                                            }
                                        }
                                    )
                                }
                                .testTag("btn_drive_gas")
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize().padding(4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("G\nA\nS", color = Color.Black, fontWeight = FontWeight.ExtraBold, fontSize = 10.sp, textAlign = TextAlign.Center)
                                Icon(Icons.Filled.Upload, "Gas Icon", tint = Color.Black, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Row 2: Transmission Gear Lever (P, R, N, D) & Dual Honking Panel
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Gear Shifter Segment
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF1E293B)),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("P", "R", "N", "D").forEach { g ->
                            val isActive = gear == g
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isActive) GoldAccent else Color.Transparent)
                                    .clickable { viewModel.setGear(g) }
                                    .testTag("gear_$g"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    g,
                                    color = if (isActive) Color.Black else Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }

                    // Dual Horn buttons (Standard beep vs Hydraulic Rhythmic multi-tone!)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Standard Horn (Pulsing flasher)
                        Button(
                            onClick = {
                                // Trigger standard flash loop in coroutine
                                hornFlashCount = 1
                                scope.launch {
                                    delay(400)
                                    hornFlashCount = 0
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF455A64)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.height(40.dp).testTag("btn_drive_horn")
                        ) {
                            Icon(Icons.Filled.VolumeUp, "Horn")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(GameLocale.tr("horn", lang), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        // Local Legendary Musical Hydraulic Horn!
                        Button(
                            onClick = {
                                hydraulicFlashCount = 1
                                scope.launch {
                                    delay(1200)
                                    hydraulicFlashCount = 0
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SignalRed),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.height(40.dp).testTag("btn_drive_hydraulic")
                        ) {
                            Icon(Icons.Filled.MusicNote, "Hydraulic Horn")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(GameLocale.tr("hydraulic_horn", lang), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DashboardGlowIndicator(label: String, progress: Float, color: Color) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(label, color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Box(
            modifier = Modifier
                .width(45.dp)
                .height(8.dp)
                .clip(CircleShape)
                .background(Color(0xFF334155))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(progress)
                    .fillMaxHeight()
                    .background(color)
            )
        }
    }
}

@Composable
fun DashboardSmallToggle(icon: ImageVector, active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(if (active) GoldAccent else Color(0xFF1E293B))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = "Control",
            tint = if (active) Color.Black else Color.White,
            modifier = Modifier.size(18.dp)
        )
    }
}
