package com.example.game

// Localization Helper
object GameLocale {
    private val enStrings = mapOf(
        "app_title" to "Bangladesh Bus Simulator",
        "play_career" to "Career Mode",
        "play_free" to "Free Roam",
        "garage" to "Bus Garage",
        "stats" to "Statistics",
        "settings" to "Settings",
        "back" to "Back",
        "start_driving" to "Start Journey",
        "select_route" to "Select Highway Route",
        "locked" to "LOCKED",
        "buy" to "Buy for ৳",
        "unlocked" to "Owned",
        "select" to "Select",
        "selected" to "Active",
        "money" to "Money: ৳",
        "speed" to "Speed: ",
        "kmh" to " km/h",
        "rpm" to "RPM: ",
        "fuel" to "Fuel: ",
        "damage" to "Damage: ",
        "passenger" to "Passengers: ",
        "boarding" to "BOARDING PASSENGERS...",
        "boarding_done" to "All passengers boarded! Close doors & drive.",
        "terminal_arrival" to "Welcome to the Terminal! Stop inside the marker.",
        "arrival_payout" to "Journey Completed! Passengers offboarded.",
        "earned" to "Earned: ৳",
        "fine_speed" to "Speeding Fine! Deducted ৳200",
        "fine_crash" to "Accident Fine! Deducted ৳150",
        "toll_plaza" to "Toll Plaza! Paid ৳100",
        "railway_gate" to "Railway gate closed! Train is crossing.",
        "ferry_boarding" to "Drive onto the Ferry carefully!",
        "ferry_crossing" to "Ferry Crossing River... Enjoy the tea stall music!",
        "refuel_success" to "Bus Fully Refueled! Spent ৳",
        "repair_success" to "Bus Fully Repaired! Spent ৳",
        "wash_success" to "Bus Cleaned! Spent ৳50",
        "horn" to "HORN",
        "hydraulic_horn" to "HYDRAULIC HORN",
        "wipers" to "WIPER",
        "doors" to "DOOR",
        "lights" to "LIGHTS",
        "weather" to "Weather: ",
        "sunny" to "Sunny",
        "rain" to "Monsoon Rain",
        "fog" to "Winter Fog",
        "night" to "Night Highway",
        "language" to "Language",
        "volume" to "Sound Effects Volume",
        "graphics" to "Graphics Quality",
        "controls" to "Steering Controls",
        "save" to "Progress Auto-Saved",
        "career_progress" to "Career History",
        "distance" to "Total Distance Driven: ",
        "fares" to "Total Cash Earned: ৳",
        "passengers_total" to "Total Passengers Safe: ",
        "violations" to "Traffic Violations: ",
        "route_dhaka_sylhet" to "Dhaka to Sylhet (Tea Gardens Route)",
        "route_dhaka_ctg" to "Dhaka to Chattogram (Comilla Highway)",
        "route_dhaka_barishal" to "Dhaka to Barishal (Padma Bridge & Ferry)",
        "route_ctg_cox" to "Chattogram to Cox's Bazar (Hilly Winding Roads)",
        "route_dhaka_rajshahi" to "Dhaka to Rajshahi (Jamuna Crossing)"
    )

    private val bnStrings = mapOf(
        "app_title" to "বাংলাদেশ বাস সিমুলেটর",
        "play_career" to "ক্যারিয়ার মোড",
        "play_free" to "ফ্রি রোম ড্রাইভ",
        "garage" to "বাস গ্যারেজ",
        "stats" to "পরিসংখ্যান",
        "settings" to "সেটিংস",
        "back" to "পিছনে",
        "start_driving" to "যাত্রা শুরু করুন",
        "select_route" to "মহাসড়ক রুট নির্বাচন",
        "locked" to "লক করা",
        "buy" to "কিনুন: ৳",
        "unlocked" to "নিজের বাস",
        "select" to "বাছাই করুন",
        "selected" to "চালু আছে",
        "money" to "টাকা: ৳",
        "speed" to "গতি: ",
        "kmh" to " কিমি/ঘণ্টা",
        "rpm" to "আরপিএম: ",
        "fuel" to "জ্বালানি: ",
        "damage" to "ক্ষতি: ",
        "passenger" to "যাত্রী: ",
        "boarding" to "যাত্রী উঠানো হচ্ছে...",
        "boarding_done" to "সব যাত্রী উঠেছে! দরজা বন্ধ করে ড্রাইভ করুন।",
        "terminal_arrival" to "টার্মিনালে স্বাগতম! মার্কারের ভেতরে থামুন।",
        "arrival_payout" to "যাত্রা সম্পন্ন! যাত্রী নেমে গেছে।",
        "earned" to "উপার্জন: ৳",
        "fine_speed" to "গতিসীমা লংঘন জরিমানা! কাটা গেল ৳২০০",
        "fine_crash" to "দুর্ঘটনা জরিমানা! কাটা গেল ৳১৫০",
        "toll_plaza" to "টোল প্লাজা! টোল পরিশোধ ৳১০০",
        "railway_gate" to "রেলক্রসিং গেট বন্ধ! ট্রেন পার হচ্ছে।",
        "ferry_boarding" to "সাবধানে ফেরিতে বাস উঠান!",
        "ferry_crossing" to "নদী পার হচ্ছে ফেরি... চা স্টলের গান শুনুন!",
        "refuel_success" to "তেল ভরা সম্পন্ন! খরচ ৳",
        "repair_success" to "বাস মেরামত সম্পন্ন! খরচ ৳",
        "wash_success" to "বাস ধোয়া সম্পন্ন! খরচ ৳৫০",
        "horn" to "হর্ন",
        "hydraulic_horn" to "হাইড্রোলিক হর্ন",
        "wipers" to "ওয়াইপার",
        "doors" to "দরজা",
        "lights" to "লাইট",
        "weather" to "আবহাওয়া: ",
        "sunny" to "রৌদ্রোজ্জ্বল",
        "rain" to "বর্ষার বৃষ্টি",
        "fog" to "শীতের কুয়াশা",
        "night" to "রাতের মহাসড়ক",
        "language" to "ভাষা পরিবর্তন",
        "volume" to "শব্দের ভলিউম",
        "graphics" to "গ্রাফিক্স কোয়ালিটি",
        "controls" to "স্টিয়ারিং কন্ট্রোল",
        "save" to "অগ্রগতি সংরক্ষিত",
        "career_progress" to "ক্যারিয়ার ইতিহাস",
        "distance" to "মোট ড্রাইভ করা দূরত্ব: ",
        "fares" to "মোট আয় টাকা: ৳",
        "passengers_total" to "নিরাপদ যাত্রী পরিবহন: ",
        "violations" to "ট্রাফিক আইন লংঘন: ",
        "route_dhaka_sylhet" to "ঢাকা থেকে সিলেট (চা বাগান রুট)",
        "route_dhaka_ctg" to "ঢাকা থেকে চট্টগ্রাম (কুমিল্লা মহাসড়ক)",
        "route_dhaka_barishal" to "ঢাকা থেকে বরিশাল (পদ্মা সেতু ও ফেরি)",
        "route_ctg_cox" to "চট্টগ্রাম থেকে কক্সবাজার (পাহাড়ি আঁকাবাঁকা পথ)",
        "route_dhaka_rajshahi" to "ঢাকা থেকে রাজশাহী (যমুনা পারাপার)"
    )

    fun tr(key: String, lang: String): String {
        return if (lang == "bn") {
            bnStrings[key] ?: enStrings[key] ?: key
        } else {
            enStrings[key] ?: key
        }
    }
}

// Skins Definition
data class SkinSpec(
    val id: String,
    val name: String,
    val bodyColorHex: String,
    val stripeColorHex: String,
    val accentColorHex: String
)

// Bus Model Specification
data class BusSpec(
    val id: String,
    val name: String,
    val price: Int,
    val maxSpeed: Float, // speed coefficient
    val acceleration: Float,
    val weight: Float,
    val fuelEfficiency: Float, // km per liter
    val capacity: Int,
    val skins: List<SkinSpec>
)

object BusRegistry {
    val buses = listOf(
        BusSpec(
            id = "Ashok Leyland",
            name = "Ashok Leyland Non-AC",
            price = 0, // Starter Bus
            maxSpeed = 80f,
            acceleration = 1.2f,
            weight = 12000f,
            fuelEfficiency = 4.2f,
            capacity = 40,
            skins = listOf(
                SkinSpec("BRTC", "BRTC Govt Red", "#D32F2F", "#FFFFFF", "#1E88E5"),
                SkinSpec("Shyamoli", "Shyamoli Classic", "#0D47A1", "#FFD54F", "#00C853"),
                SkinSpec("Hanif Travels", "Hanif Red-White", "#D50000", "#FFFFFF", "#212121")
            )
        ),
        BusSpec(
            id = "Hino 1J",
            name = "Hino 1J Deluxe AC",
            price = 8000,
            maxSpeed = 100f,
            acceleration = 1.5f,
            weight = 11500f,
            fuelEfficiency = 3.8f,
            capacity = 36,
            skins = listOf(
                SkinSpec("Ena", "Ena Express", "#FFD54F", "#E65100", "#1B5E20"),
                SkinSpec("Nabil", "Nabil Enterprise", "#1E88E5", "#FFEB3B", "#D32F2F"),
                SkinSpec("Saintmartin Travels", "Saintmartin Sea breeze", "#00838F", "#E0F7FA", "#FF5252")
            )
        ),
        BusSpec(
            id = "Hyundai Universe",
            name = "Hyundai Universe Luxury",
            price = 18000,
            maxSpeed = 120f,
            acceleration = 1.8f,
            weight = 13000f,
            fuelEfficiency = 3.5f,
            capacity = 32,
            skins = listOf(
                SkinSpec("Green Line", "Green Line AC", "#2E7D32", "#FFFFFF", "#FFEB3B"),
                SkinSpec("Desh Travels", "Desh Royal Class", "#512DA8", "#FF4081", "#E0F2F1")
            )
        ),
        BusSpec(
            id = "Volvo B11R",
            name = "Volvo B11R Multi-Axle",
            price = 32000,
            maxSpeed = 135f,
            acceleration = 2.2f,
            weight = 15000f,
            fuelEfficiency = 2.8f,
            capacity = 45,
            skins = listOf(
                SkinSpec("Shohagh", "Shohagh Platinum", "#D84315", "#ECEFF1", "#37474F"),
                SkinSpec("Green Line VIP", "Green Line Double Axle", "#1B5E20", "#FFD54F", "#D50000")
            )
        ),
        BusSpec(
            id = "Scania Multiaxle",
            name = "Scania K410 Executive",
            price = 50000,
            maxSpeed = 145f,
            acceleration = 2.5f,
            weight = 16000f,
            fuelEfficiency = 2.5f,
            capacity = 42,
            skins = listOf(
                SkinSpec("Hanif VIP", "Hanif Scania Coach", "#B71C1C", "#FFD54F", "#FFFFFF"),
                SkinSpec("Silk Line", "Silk Line Premium", "#212121", "#FFD54F", "#FF8F00")
            )
        )
    )

    fun getBus(id: String): BusSpec {
        return buses.firstOrNull { it.id == id } ?: buses[0]
    }
}

// Highway Route definitions
data class RouteSpec(
    val id: String,
    val nameKey: String,
    val startCity: String,
    val endCity: String,
    val distanceKm: Double,
    val rewardTaka: Int,
    val hasFerry: Boolean = false,
    val hasBridge: Boolean = false,
    val bridgeName: String = "",
    val hasToll: Boolean = false,
    val hasRailwayCrossing: Boolean = false,
    val defaultWeather: String = "Sunny" // "Sunny", "Rain", "Fog", "Night"
)

object RouteRegistry {
    val routes = listOf(
        RouteSpec(
            id = "dhaka_sylhet",
            nameKey = "route_dhaka_sylhet",
            startCity = "Dhaka",
            endCity = "Sylhet",
            distanceKm = 240.0,
            rewardTaka = 2500,
            hasBridge = true,
            bridgeName = "Bhairab Bridge",
            hasRailwayCrossing = true,
            defaultWeather = "Rain" // Green & wet tea gardens
        ),
        RouteSpec(
            id = "dhaka_ctg",
            nameKey = "route_dhaka_ctg",
            startCity = "Dhaka",
            endCity = "Chattogram",
            distanceKm = 260.0,
            rewardTaka = 3000,
            hasToll = true,
            hasBridge = true,
            bridgeName = "Meghna Bridge",
            defaultWeather = "Sunny"
        ),
        RouteSpec(
            id = "dhaka_barishal",
            nameKey = "route_dhaka_barishal",
            startCity = "Dhaka",
            endCity = "Barishal",
            distanceKm = 200.0,
            rewardTaka = 2800,
            hasBridge = true,
            bridgeName = "Padma Bridge",
            hasFerry = true, // Scenic ferry transit
            defaultWeather = "Fog"
        ),
        RouteSpec(
            id = "ctg_cox",
            nameKey = "route_ctg_cox",
            startCity = "Chattogram",
            endCity = "Cox's Bazar",
            distanceKm = 150.0,
            rewardTaka = 1800,
            hasBridge = true,
            bridgeName = "Karnaphuli Bridge",
            defaultWeather = "Night" // Driving along beaches under night moonlight
        ),
        RouteSpec(
            id = "dhaka_rajshahi",
            nameKey = "route_dhaka_rajshahi",
            startCity = "Dhaka",
            endCity = "Rajshahi",
            distanceKm = 250.0,
            rewardTaka = 2600,
            hasBridge = true,
            bridgeName = "Bangabandhu Jamuna Bridge",
            hasRailwayCrossing = true,
            defaultWeather = "Sunny"
        )
    )

    fun getRoute(id: String): RouteSpec {
        return routes.firstOrNull { it.id == id } ?: routes[0]
    }
}
